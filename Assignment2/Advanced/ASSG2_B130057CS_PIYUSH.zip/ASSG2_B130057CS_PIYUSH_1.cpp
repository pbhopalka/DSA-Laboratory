#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <climits>

using namespace std;

int data[100000001];

int merge (int start, int mid, int end){
	int leftLength = mid - start + 1;
	int rightLength = end - mid;
	int leftArray[leftLength + 1], rightArray[rightLength + 1], i;
	for (i = 0; i < leftLength; i++)
		leftArray[i] = data[start + i];
	leftArray[i] = INT_MAX;
	for (i = 0; i < rightLength; i++)
		rightArray[i] = data[mid + i + 1];
	rightArray[i] = INT_MAX;
	int j = 0;
	i = 0;
	for (int k = start; k <= end; k++){
		if (leftArray[i] <= rightArray[j]){
			data[k] = leftArray[i];
			i++;
		}
		else {
			data[k] = rightArray[j];
			j++;
		}
	}
	return 0;
}

int mergesort (int start, int end){
	if (start < end){
		int mid = (start + end)/2;
		mergesort (start, mid);
		mergesort (mid+1, end);
		merge (start, mid, end);
	}
	return 0;
}

int minimum (int array[], int size){
	int min = 0;
	for (int i = 1; i < size; i++){
		if (array[i] < array[min])
			min = i;
	}
	return min;
}

int finalMerge() {
	char filename[] = "BigFile.txt";
	int p[2], j = 0;
	fstream file[2], file2;
	file[0].open("temporary0.txt", ios::in|ios::binary);
	file[1].open("temporary1.txt", ios::in|ios::binary);
	file2.open(filename, ios::out);
	/*
	for (i = 0; i < 33554432; i++)
		file[0] >> data[i];
	for (i = 33554432; i < 67108864; i++)
		file[1] >> data[i];
	merge (0, 33554432, 67108863);
	for (i = 0; i < 67108864; i++)
		file2 << data[i];
	*/
	for (int i = 0; i < 2; i++)
		file[i].read((char *)&p[i], sizeof(p[i]));
	while (j < 67108864){
		int min = minimum(p, 2);
		file2 << p[min] << "\n";
		if (! file[min].eof())
			file[min].read((char *)&p[min], sizeof(p[min]));
			//file[min] >> p[min];
		else 
			p[min] = INT_MAX;
		j++;
	}
	file2.close();
	file[0].close();
	file[1].close();
	remove("temporary0.txt");
	remove("temporary1.txt");
	return 0;
}

int mergeInto2(char start, char filename2[]){
	char filename[] = "temp00.txt";
	int j = 0, p[4] = {0};
	filename[5] = start;
	fstream file[4];
	for (int i = 0; i < 4; i++){
		file[i].open(filename, ios::in|ios::binary);
		filename[5] = filename[5]+1;
	}
	fstream file2;
	file2.open(filename2, ios::out|ios::binary);
	for (int i = 0; i < 4; i++)
		file[i].read((char *)&p[i], sizeof(p[i]));
	while (j < 33554432){
		int min = minimum(p, 4);
		
		file2.write((char *)&p[min], sizeof(p[min]));
		//file2 << p[min] << "\n";
		if (! file[min].eof())
			file[min].read((char *)&p[min], sizeof(p[min]));
		else
			p[min] = INT_MAX;
		j++;
	}
	file2.close();
	filename[5] = start;
	for (int i = 0; i < 4; i++){
		file[i].close();
		remove(filename);
		filename[5] = filename[5]+1;
	}	
	return 0;
}

int mergeInto8(char start[], char filename2[]) {
	char filename[] = "temporary00.txt";
	int j = 0, p[8] = {0};
	filename[9] = start[0];
	filename[10] = start[1];
	fstream file[8];
	for (int i = 0; i < 8; i++){
		
		file[i].open(filename, ios::in|ios::binary);
		if (filename[10] == '9'){
			filename[10] = '0';
			filename[9] = filename[9] + 1;
		}
		else
			filename[10] = filename[10]+1;
	}
	fstream file2;
	file2.open(filename2, ios::out);
	for (int i = 0; i < 8; i++)
		file[i].read((char *)&p[i], sizeof(p[i]));
	while (j < 8388608){
		int min = minimum(p, 8);
		file2.write((char *)&p[min], sizeof(p[min]));
		if (! file[min].eof())
			file[min].read((char *)&p[min], sizeof(p[min]));
		else
			p[min] = INT_MAX;
		j++;
	}
	file2.close();
	filename[9] = start[0];
	filename[10] = start[1];
	for (int i = 0; i < 8; i++){
		file[i].close();
		remove(filename);
		if (filename[10] == '9'){
			filename[10] = '0';
			filename[9] = filename[9] + 1;
		}
		else
			filename[10] = filename[10]+1;
	}	
	return 0;
	
}

int breakInto64AndSort(){
	char filename[] = "temporary00.txt";
	int count = 1;
	fstream file;
	file.open("BigFile.txt", ios::in);
	for (int i = 0; i < 64; i++){
		if (filename[10] == '9'){
			filename[10] = '0';
			filename[9] = filename[9] + 1;
		}
		else
			filename[10] = filename[10]+1;
		fstream file2;
		file2.open(filename, ios::out|ios::binary);
		for (int j = 0; j < 1048576; j++){
			//file.read((char *)&data[j], sizeof(data[j]));
			file >> data[j];
		}
		cout << "Sorting file no. " << count << "\n"; 
		mergesort(0, 1048575);
		for (int j = 0; j < 1048576; j++){
			file2.write((char *)&data[j], sizeof(data[j]));
			//file2 << data[j] << "\n";
		}
		file2.close();
		count++;
	}
	file.close();
	return 0;
}
	

int generateBigfile (){
	fstream file;
	file.open("BigFile.txt", ios::out);
	for (int i = 0; i < 67108864; i++){ 
		file << rand() << "\n";
	}
	file.close();
	return 0;
}

int main(){
	clock_t start, end;
	cout << "BigFile Generation Begun\n";
	
	generateBigfile ();
	cout << "BigFile Generated\n";
	start = clock();
	cout << "\nBreaking the files\n\n";
	breakInto64AndSort();
	cout << "\n64 files created and each one sorted\n";
	end = clock();
	cout << "The total time taken: " << (double)(end-start)/CLOCKS_PER_SEC << " s\n";
	
	//8-way merge
	char filename[] = {"temp00.txt"};
	char pos[] = "01";
	for (int i = 0; i < 8; i++){
		filename[5] = filename[5]+1;	
		cout << "Merging 8 files\n";
		mergeInto8(pos, filename);
		if (pos[1] == '1')
			pos[1] = '9';
		else{
			pos[1] = pos[1] - 2;
			pos[0] = pos[0] + 1;
		}
	}
	end = clock();
	cout << "The total time taken: " << (double)(end-start)/CLOCKS_PER_SEC << " s\n";
	
	//4-way merge
	cout << "\nMerging 4 files\n";
	char pos1 = '1';
	char filename2[] = {"temporary0.txt"};
	mergeInto2(pos1, filename2);
	cout << "Merging 4 files\n";
	pos1 = '5';
	char filename3[] = {"temporary1.txt"};
	mergeInto2(pos1, filename3);
	end = clock();
	cout << "The total time taken: " << (double)(end-start)/CLOCKS_PER_SEC << " s\n";
	
	//2-way merge
	cout << "\nMerging the last two files\n";
	finalMerge();
	end = clock();
	
	cout << "\nSorting Completed\n";
	cout << "The total time taken: " << (double)(end-start)/CLOCKS_PER_SEC << " s";
}
