#include <iostream>
#include <ctime>

using namespace std;

int dataSize;
int data[10000001];

int swap (int i, int j){
	int temp;
	temp = data[i];
	data[i] = data[j];
	data[j] = temp;
	return 0;
}

int insertionSort(int start, int end){
	for (int j = start + 1; j <= end; j++){
		int key = data[j];
		int i = j - 1;
		while ((i >= start) && (data[i] > key)){
			data[i+1] = data[i];
			i--;
		}
		data[i+1] = key;
	}
	return 0;
}

int medianOfMedian(int start, int arraySize){
	/*
	cout<<"Me of Me Array: "<<'\n';
	for(int i=start; i<=arraySize;i++)
		cout<<data[i]<<' ';
	cout<<'\n';
	*/	
	//cout << "Median of Median  start: "<<start<<"size: "<<arraySize<<'\n';
	int j = start, medianElement;
	if (start == arraySize)
		return start;
	for (int i = start; i <= arraySize; i = i+5){
		if (i+5 > arraySize){
			insertionSort(i, arraySize);
			medianElement = (i + arraySize)/2; 
		}
		else
		{
			insertionSort(i, i+4);
			medianElement = (i + i + 4)/2;
		}
		swap(j, medianElement);
		j++;
	}
	int s = medianOfMedian(start, j - 1);	 
	return s;
	
}

int partition (int start, int end){
	int median = medianOfMedian(start, end);
	/*
	cout<<"Array after Me of Me\n";
	for(int i=start;i<=end;i++)
		cout<<data[i]<<' ';
	cout<<'\n';
	*/
	int key = data[median];
	swap(end, median);
	int index = start - 1;
	for (int i = start; i <= end - 1; i++){
		if (data[i] <= key){
			index++;
			swap(index, i);
		}
	}
	swap(index+1, end);
	return (index+1);
}

int Select (int start, int end, int index){
	if (start == end)
		return data[start];
	int mid = partition (start, end);
	/*
	cout<<"Array:\n";
	for(int i=0;i<dataSize;i++)
		cout<<data[i]<<' ';
	cout<<endl;
	*/
	int pivot = mid;
	if (index == pivot){
		return data[mid];}
	else if (index < pivot)
		return Select(start, mid-1, index);
	else
		return Select(mid + 1, end, index);
}

double findMedian (int arraySize){
	int medianElement = (arraySize)/2;
	if (arraySize % 2 == 0){
		int lowerLimit = Select(0, arraySize - 1, (arraySize/2) - 1);
		//cout << "Lowelimit: "<< lowerLimit << '\n'; 
		int higherLimit = Select(0, arraySize - 1, (arraySize/2));
		//cout << "HigherLimit: "<< higherLimit << '\n';
		double answer = (double) (higherLimit + lowerLimit)/2;
		//cout << answer << '\n';
		return answer;
	}
	return (double)Select (0, arraySize - 1, medianElement);
} 

int main(){
	cin >> dataSize;
	clock_t start, end;
	for (int i = 0; i < dataSize; i++)
		cin >> data[i];
	start = clock();	
	double median = findMedian(dataSize);
	end = clock();
	cout << "\n";
	cout << median << "\n";
	cout << "The running time is: " << (double) (end - start)/CLOCKS_PER_SEC << " s\n";
	return 0;
}
