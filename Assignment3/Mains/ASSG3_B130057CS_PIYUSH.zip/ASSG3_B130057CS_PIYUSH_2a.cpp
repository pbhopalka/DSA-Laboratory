#include <iostream>
#include <cstdio>

using namespace std;

//int array[1000001];
int arraySize;
int size = 0;
int startIndex = 0;
int endIndex = 0;

int show (int array[]){
	if (size == 0){
		cout << "EMPTY\n";
		return 0;
	}
	int temp = startIndex;
	for (int i = 0; i < size; i++){
		cout << array[temp] << " ";
		if (temp == arraySize - 1)
			temp = 0;
		else
			temp++;
	}
	cout << "\n";
	return 0;
}
	

int peek (int queue[]){
	if (size == 0){
		cout << "EMPTY\n";
		return 0;
	}
	cout << queue[startIndex] << "\n";
	return 0;
}

int dequeue (int queue[]){
	if (size == 0){
		cout << "EMPTY\n";
		return 0;
	}
	cout << queue[startIndex]<< "\n";
	
	if (startIndex == arraySize - 1)
		startIndex = 0;
	else
		startIndex++;
	size--;
	//printArray(queue);
	return 0;
}

int enqueue(int queue[], int element){
	if (size == arraySize){
		cout << "Overflow\n";
		return 0;
	}
	
	queue[endIndex] = element;
	size++;
	//printArray(queue);
	if (endIndex == arraySize -1)
		endIndex = 0;
	else
		endIndex++;
	
	
	return 0;
}

int main(){
	cin >> arraySize;
	if ((arraySize <= 0) || (arraySize >= 100)){
		cout << "Invalid Array Size\n";
		return 0;
	}
	int array[arraySize+1];
	int option, element;
	char c;
	while(1){
		//option = getchar();
		cin >> option;
		switch(option){
			case 0:
				return 0;
			case 1:
				c= getchar();
				if (c != ' '){
					cout << "Input Error\n";
					break;
				}
				cin >> element;
				if (element < 0){
					cout << "Element cannot be less than zero.\n";
					break;
				}
				enqueue(array, element);
				break;
			case 2:
				dequeue(array);
				break;
			case 3:
				peek(array);
				break;
			case 4:
				show(array);
				break;
			default:
				cout << "Invalid choice\n";
		}
	}
	return 0;
}
