#include <iostream>
#include <cstdio>

using namespace std;

struct node{
	int number;
	node *next;
} *head = NULL, *item = NULL;

int enqueue(int element){
	node *temp;
	temp = new node;
	temp->number = element;
	temp->next = NULL;
	if (head == NULL)
		head = temp;
	if (item == NULL){
		item = temp;
	}
	else{
		item->next = temp;
		item = temp;
	}
	
	return 0;
}

int dequeue(){
	node *temp;
	temp = head;
	if (temp == NULL){
		cout << "EMPTY\n";
		return 0;
	}
	head = head->next;
	cout << temp->number << "\n";
	delete(temp);
	return 0;	
}

int peek(){
	if (head == NULL){
		cout << "EMPTY\n";
		return 0;
	}
	cout << head->number << "\n";
	return 0;
}

int show(){
	node *temp;
	temp = head;
	if (temp == NULL){
		cout << "EMPTY\n";
		return 0;
	}
	while (temp != NULL){
		cout << temp->number << " ";
		temp = temp->next;
	}
	cout << "\n";
	return 0;
}

int searchList(int element){
	node *search;
	search = head;
	if (head == NULL){
		cout << "EMPTY\n";
		return 0;
	}
	while (search != NULL && search->number != element)
		search = search->next;
	return 0;
} 

int main(){
	int choice, num;
	char c;
	while (1){
		cin >> choice;
		switch(choice){
			case 0:
				return 0;
			case 1:
				c= getchar();
				if (c != ' '){
					cout << "Input Error\n";
					break;
				}
				cin >> num;
				if (num < 0){
					cout << "Element cannot be less than zero.\n";
					break;
				}
				enqueue(num);
				break;
			case 2:
				dequeue();
				break;
			case 3:
				peek();
				break;
			case 4:
				show();
				break;
			default:
				cout << "Invalid choice\n";
		}
	}
	return 0;
}	

