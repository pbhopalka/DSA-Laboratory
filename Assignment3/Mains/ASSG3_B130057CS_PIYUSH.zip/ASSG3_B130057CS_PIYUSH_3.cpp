#include <iostream>
#include <climits>
#include <cstdio>

using namespace std;

int pValue[10000000];
int array[10000000];
int heapSize = -1;

int parent (int index){
	return index/2;
}

int leftChild (int index){
	return index*2;
}

int rightChild (int index){
	return leftChild(index)+1;
}

int swap (int someArray[], int i, int j){
	int temp;
	temp  = someArray[i];
	someArray[i] = someArray[j];
	someArray[j] = temp;
	return 0;
}

int maxHeapify(int index) {
	int largest;
	int left = leftChild (index);
	int right = rightChild (index);
	if ((left <= heapSize) && (pValue[left] < pValue[index]))
		largest = left;
	else
		largest = index;
	if ((right <= heapSize) && (pValue[right] < pValue[index]))
		largest = right;
	if (largest != index){
		swap (pValue, index, largest);
		swap (array, index, largest);
		maxHeapify(largest);
	}
	return 0;
}

int remove() {
	if (heapSize < 0){
		cout << "EMPTY\n";
		return 0;
	}
	int minInArray = array[0];
	int minInPvalue = pValue[0];
	array[0] = array[heapSize];
	pValue[0] = pValue[heapSize];
	heapSize--;
	maxHeapify(0);
	cout << minInArray << " (" << minInPvalue <<")\n";
	return 0;
}

int peek() {
	if (heapSize < 0){
		cout << "EMPTY\n";
		return 0;
	}
	cout << array[0] << " (" << pValue[0]<<")\n";
	return 0;
}

int increaseKey(int index, int element){
	pValue[index] = element;
	while (index > 0 && pValue[parent(index)] > pValue[index]){
		swap (pValue, index, parent(index));
		swap (array, index, parent(index));
		index = parent(index);
	}
	return index;
}

int insert(int element, int priority) {
	heapSize++;
	pValue[heapSize] = INT_MIN;
	array[heapSize] = INT_MIN;
	int index = increaseKey(heapSize, priority);
	array[index] = element;
	return 0;
}

int searchList (int element){
	for (int i = 0; i <= heapSize; i++){
		if (array[i] == element)
			return i;
	}
	return -1;
}

int main(){
	int choice, num, prior;
	char c;
	while (1){
		cin >> choice;
		switch(choice){
			case 0:
				return 0;
			case 1:
				c= getchar();
				if (c != ' '){
					cout << "Input Error\n";
					break;
				}
				cin >> num;
				if (num < 0){
					cout << "Invalid Input Number.\n";
					break;
				}
				c = getchar();
				if (c != ' '){
					cout << "Input Error\n";
					break;
				}
				cin >> prior;
				if (prior < 1){
					cout << "Invalid Priority.\n";
					break;
				}
				insert(num, prior);
				break;
			case 2:
				remove();
				break;
			case 3:
				peek();
				break;
			case 4:
				int newData, indexed;
				cin >> num;
				if (num < 0){
					cout << "Invalid Input Number.\n";
					break;
				}
				c = getchar();
				if (c != ' '){
					cout << "Input Error\n";
					break;
				}
				cin >> newData;
				if (newData < 1){
					cout << "Invalid Input Number.\n";
					break;
				}
				indexed = searchList(num);
				if (indexed == -1){
					cout << "Element entered doesn't exist.\n";
					break;
				}
				increaseKey(indexed, newData);
				break;
			default:
				cout << "Invalid choice\n";
		}
	}
	return 0;
}
	
