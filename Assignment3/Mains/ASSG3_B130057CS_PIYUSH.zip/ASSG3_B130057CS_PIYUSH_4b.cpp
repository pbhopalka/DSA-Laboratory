#include <iostream>

using namespace std;

struct node{
	int number;
	node *next;
	node *previous;
} *head = NULL, *item = NULL;

int enqueue(int element){
	node *temp;
	temp = new node;
	temp->number = element;
	temp->previous = NULL;
	temp->next = NULL;
	if (head == NULL){
		head = temp;
	}
	else if (item == NULL){
		item = temp;
		item->previous = head;
		head->next = item;
	}
	else{
		item->next = temp;
		temp->previous = item;
		item = temp;
	}
	
	return 0;
}

int dequeue(int x){
	node *temp;
	temp = head;
	//cout << "Value of i: " << x << endl;
	for (int i = 0; i < x; i++){
		temp = temp->next;
	}
	if (temp->previous != NULL)
		temp->previous->next = temp->next;
	else
		head = temp->next;
	if (temp->next != NULL)
		temp->next->previous = temp->previous;
	//cout << "Deleting: " << temp->number << "\n";
	delete (temp);
	return 0;	
}

int show(){
	node *temp;
	temp = head;
	if (temp == NULL){
		cout << "EMPTY\n";
		return 0;
	}
	while (temp != NULL){
		cout << temp->number << " ";
		temp = temp->next;
	}
	cout << "\n";
	return 0;
} 

int main(){
	int num, size;
	cin >> size;
	for (int i = 0; i < size; i++){
		cin >> num;
		enqueue(num);
	}
	for (int i = 1; i < size; i++){
		size--;
		dequeue(i);
		
	}
	cout << "After deletion:\n";
	show();
	return 0;
}	


