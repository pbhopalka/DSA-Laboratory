#include <iostream>
#include <cstdio>

using namespace std;

struct node{
	int number;
	node *previous;
} *head = NULL;

int push(int element){
	node *temp;
	temp = new node;
	//cout <<"Before size: " << size << "\n";
	temp->number = element;
	temp->previous = NULL;
	if (head == NULL)
		head = temp;
	else{
		temp->previous = head;
		head = temp;
		//cout << "After Size: " << ++size << "\n";
	}
	
	return 0;
}

int pop(){
	node *temp;
	temp = head;
	
	if (temp == NULL){
		cout << "EMPTY\n";
		return 0;
	}
	/*if (head->previous == NULL){
		cout << (*head).number << "\n";
		head = NULL;
	}
	else{*/
		head = head->previous;
		cout << temp->number << "\n";
		delete(temp);
	return 0;	
}

int peek(){
	if (head == NULL){
		cout << "EMPTY\n";
		return 0;
	}
	cout << head->number << "\n";
	return 0;
}

int show(){
	node *temp;
	temp = head;
	if (temp == NULL){
		cout << "EMPTY\n";
		return 0;
	}
	while (temp != NULL){
		cout << temp->number << " ";
		temp = temp->previous;
	}
	cout << "\n";
	return 0;
}

int main(){
	int choice, num;
	char c;
	while (1){
		cin >> choice;
		switch(choice){
			case 0:
				return 0;
			case 1:
				c= getchar();
				if (c != ' '){
					cout << "Input Error\n";
					break;
				}
				cin >> num;
				if (num < 0){
					cout << "Invalid element entry!\n";
					break;
				}
				push(num);
				break;
			case 2:
				pop();
				break;
			case 3:
				peek();
				break;
			case 4:
				show();
				break;
			default:
				cout << "Wrong choice\n";
		}
	}
	return 0;
}	
