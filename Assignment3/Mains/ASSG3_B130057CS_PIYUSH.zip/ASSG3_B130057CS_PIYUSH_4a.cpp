#include <iostream>

using namespace std;

struct node{
	int number;
	node *next;
} *head = NULL, *item = NULL;

int enqueue(int element){
	node *temp;
	temp = new node;
	temp->number = element;
	temp->next = NULL;
	if (head == NULL)
		head = temp;
	if (item == NULL){
		item = temp;
	}
	else{
		item->next = temp;
		item = temp;
	}
	
	return 0;
}
/*
int dequeue(){
	node *temp;
	temp = head;
	if (temp == NULL){
		cout << "EMPTY\n";
		return 0;
	}
	head = head->next;
	cout << temp->number << "\n";
	delete(temp);
	return 0;	
}

int peek(){
	if (head == NULL){
		cout << "EMPTY\n";
		return 0;
	}
	cout << head->number << "\n";
	return (head->number);
}

int show(){
	node *temp;
	temp = head;
	if (temp == NULL){
		cout << "EMPTY\n";
		return 0;
	}
	while (temp != NULL){
		cout << temp->number << " ";
		temp = temp->next;
	}
	cout << "\n";
	return 0;
}

int searchList(int element){
	node *search;
	search = head;
	if (head == NULL){
		cout << "EMPTY\n";
		return 0;
	}
	while (search != NULL && search->number != element)
		search = search->next;
	return 0;
} 
*/
int main(){
	int count, num, size;
	cin >> size;
	for (int i = 0; i < size; i++){
		cin >> num;
		enqueue(num);
	}
	node *temp;
	temp = head;
	for (int i = 0; i < size; i++){
		if (temp->number > 10)
			count++;
		temp = temp->next;
	}
	cout << "\n" << count << "\n";
	return 0;
}	

