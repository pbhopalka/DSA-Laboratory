#include <iostream>
#include <cstdio>

using namespace std;

//int array[1000001];
int arraySize;
int index;

int show(int stack[]){
	int tempIndex = index;
	if (tempIndex == arraySize){
		cout << "EMPTY\n";
		return 0;
	}
	while (tempIndex != arraySize){
		cout << stack[tempIndex] << ' ';
		tempIndex++;
	}
	cout << "\n";
	return 0;
}
	

int peek (int stack[]){
	if (index == arraySize){
		cout << "EMPTY\n";
		return 0;
	}
	cout << stack[index] << "\n";
	return 0;
}

int pop (int stack[]){
	if (index == arraySize){
		cout << "EMPTY\n";
		return 0;
	}
	cout << stack[index]<< "\n";
	index++;
	return 0;
}

int push(int stack[], int element){
	if (index == 0){
		cout << "OVERFLOW\n";
		return 0;
	}
	index--;
	stack[index] = element;
	return 0;
}

int main(){
	cin >> arraySize;
	if ((arraySize < 0) || (arraySize > 100)){
		cout << "Error in range for Array Size!\n";
		return 0;
	}
	index = arraySize;
	char c;
	int array[arraySize+1];
	int option, element;
	while(1){
		//option = getchar();
		cin >> option;
		switch(option){
			case 0:
				return 0;
			case 1:
				c= getchar();
				if (c != ' '){
					cout << "Input Error\n";
					break;
				}
				cin >> element;
				if (element < 0){
					cout << "Invalid element entry!\n";
					break;
				}
				push(array, element);
				break;
			case 2:
				pop(array);
				break;
			case 3:
				peek(array);
				break;
			case 4:
				show(array);
				break;
			default:
				cout << "Wrong choice\n";
		}
	}
	return 0;
}
