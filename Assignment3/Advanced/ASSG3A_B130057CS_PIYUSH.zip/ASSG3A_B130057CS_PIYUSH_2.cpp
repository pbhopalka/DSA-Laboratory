#include <iostream>
#include <cstdio>
#include <cstdlib>

using namespace std;

struct list{
	int data;
	list *next;
	list *child;
} *head = NULL, *item = NULL;

int count = 0;

int flatten(list *node){
	list *temp, *ntemp;
	temp = node;
	while (temp != NULL){
		ntemp = node;
		while (temp->child != NULL){
			if (ntemp->next == NULL){
				temp->child->next = ntemp->next;
				ntemp->next = temp->child;
				temp->child = NULL;
			}
			else{
				ntemp = ntemp->next;
			}
		}
		temp = temp->next;
	}
	return 0;
}	

int flattenLinkedList(list *node){
	
	list *flattened, *temp;
	flattened = node;
	while (flattened->next != NULL){
		flattened = flattened->next;
	}
	temp = node;
	while (temp != NULL){
		if (temp->child != NULL){
			flattened->next = temp->child;
			temp->child = NULL;
			while(flattened->next != NULL){
				flattened = flattened->next;
			}
		}
		temp = temp->next;
	}
	return 0;
}	

int input(list *&node){
	char c;
	cout << "node: "<< node << "\n";
	int n = 0;
	list *temp;
	list *temp1;
	//temp1 = node;
	temp = new list;
	temp->child = NULL;
	temp->next = NULL;
	//cout << c << "\n";
	while(1){
		c = getchar();
		//cout << c << "\n";
		if (c == '('){
			if (n > 0){
				if (head == NULL)
					head = temp;
				if (node == NULL){
					node = temp;
					temp->child = NULL;
					temp->next = NULL;
					cout << node->data << "a\n";
					count++;
					temp1 = node;
				}
				else{
					if (temp1->data != temp->data){
						cout << temp1->data << " " << temp->data << "k\n";
						temp1->next = temp;
						temp1 = temp;
						temp1->child = NULL;
						temp1->next = NULL;
						cout << temp1->data << "b\n";
						count++;
						//temp1 = node;
					}
				}
			}
			cout << "Going\n";
			temp1->child = NULL;
			input (temp1->child);
			cout<<"node="<<temp1->data<<"\n";
			cout<<"node->child="<<temp1->child->data<<"\n";
		}
		else if (c == ' '){
			if (n > 0){
			if (head == NULL)
				head = temp;
			if (node == NULL){
				node = temp;
				temp->child = NULL;
				temp->next = NULL;
				cout << node->data << "c\n";
				count++;
				temp1 = node;
			}
			else{
				if (temp1->data != temp->data){
					cout << temp1->data << " " << temp->data << "j\n";
				cout << temp1->data << "o\n";
				temp1->next = temp;
				temp1 = temp;
				temp1->child = NULL;
				temp1->next = NULL;
				cout << temp1->data << "q\n";
				count++;
			}
			}
			}
			temp = new list;
			//temp->data = n;
			temp->child = NULL;
			temp->next = NULL;
			n = 0;
		}
		
		else if (c == ')'){
			/*temp = new list;
			temp->data = n;
			temp->child = NULL;
			temp->next = NULL;*/
			if (n > 0){
				if (head == NULL)
					head = temp;
				if (node == NULL){
					node = temp;
					temp->child = NULL;
					temp->next = NULL;
					cout << node->data << "e\n";
					count++;
					temp1 = node;
				}
				else if (temp1->data != temp->data){
					temp1->next = temp;
					temp1 = temp;
					temp1->child = NULL;
					temp1->next = NULL;
					cout << temp1->data << "f\n";
					count++;
				}
			}
			break;
		}
		else{
			n *= 10;
			n += c - '0';
			temp->data = n;
			cout << temp->data << "t\n";
			//cout << "Value of n: " << n << endl; 
		}
	}
	return 0;
}

int print()
{
	list *temp = head;
	while(temp->next != NULL)
	{
		cout << temp->data << " -> ";
		temp=temp->next;
	}
	cout << temp->data << '\n';
	return 0;	
}

int show(){
	list *temp, *ptemp;
	temp = head;
	if (temp == NULL){
		cout << "EMPTY\n";
		return 0;
	}
	while (temp != NULL){
		cout << temp->data << " ";
		temp = temp->next;
	}
	cout << "\n";
	temp = head;
	while (temp != NULL){
		ptemp = temp;
		while (ptemp != NULL){
			cout << ptemp->data << " ";
			ptemp = ptemp->child;
		}
		cout << "\n";
		temp = temp->next;
	}
	return 0;
}

int main(){
	char c;
	c = getchar();
	input(item);
	flattenLinkedList(head);
	//flatten(head);
	print();
}
		
	
