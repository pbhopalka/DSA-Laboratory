#include <iostream>
#include <cstdio>

using namespace std;

struct list{
	int data;
	list *next;
	list *down;
} *head = NULL, *item = NULL;


int flatten(list *node){
	list *temp, *ntemp;
	temp = node;
	while (temp != NULL){
		ntemp = node;
		while (temp->down != NULL){
			if ((ntemp->next == NULL) || ((temp->down->data) < (ntemp->next->data))){
				temp->down->next = ntemp->next;
				ntemp->next = temp->down;
				temp->down = NULL;
			}
			else{
				ntemp = ntemp->next;
			}
		}
		temp = temp->next;
	}
	return 0;
}		

int print()
{
	list *temp = head;
	while(temp->next != NULL)
	{
		cout << temp->data << " -> ";
		temp=temp->next;
	}
	cout << temp->data << '\n';
	return 0;	
}

int main(){
	char c;
	int count = 0;
	list *ntemp, *temp, *ptemp;
	
	//Input for the first Line
	while(1){
		temp = new list;
		cin >> temp->data;
		if (temp->data <= 0){
			cout << "Invalid Input.\n";
			return 0;
		}
		//cout << temp->data;
		count++;
		if (head == NULL)
			head = temp;
		if (item == NULL){
			item = temp;
		}
		else{
			item->next = temp;
			item = temp;
		}
		c = getchar();
		if (c == ' '){
			temp = temp->next;			
		}
		if (c == '\n'){
			break;
		}
	}
	int tempCount = count, firstCheck = 0;
	ptemp = head;
	ntemp = ptemp;
	
	while(tempCount > 0){
		temp = new list;
		cin >> temp->data;
		temp->down = NULL;
		if (firstCheck == 0){
			while (temp->data != ptemp->data){
				ptemp = ptemp->next;
				if (ptemp == NULL){
					cout << "Invalid data set.\n";
					return 0;
				}
				tempCount--;
				ntemp = ptemp;
			}
			firstCheck++;
		}
		else if (ntemp == NULL)
			ntemp = temp;
		else{
			ntemp->down = temp;
			ntemp = temp;
		}
		c = getchar();
		if (c == ' '){
			temp = temp->down;
		}
		if (c == '\n'){
			ptemp = ptemp->next;
			ntemp = ptemp; 
			firstCheck = 0;
			tempCount--;
		}
	}
	flatten(head);
	cout << "\n";
	//show();
	//cout << "\nPrint: \n";
	print();
	return 0;
}
		
	

