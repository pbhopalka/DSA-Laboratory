#include <iostream>

using namespace std;

double area(double length, double breadth){
	return ((double)length * breadth);
}

double perimeter(double length, double breadth){
	return ((double)2 * (length + breadth));
}

double (*functionPointer) (double, double);

void displayMenu() {
	cout << "\tMenu\n";
	cout << "\t\t1. Area\n";
	cout << "\t\t2. Perimeter\n";
	cout << "\t\t3. Exit\n";
	cout << "Enter the choice:\n";
}


int main() {
	double length, breadth;
	char choice;
	cout << "Enter Length" << "\n";
	if (! (cin >> length)){
		cout << "Invalid length dimension\n";
		return 0;
	}
	cout << "Enter breadth" << "\n";
	if (! (cin >> breadth)){
		cout << "Invalid breadth dimension\n";
		return 0;
	}
	if (length < 0 || breadth < 0){
		cout << "Invalid dimensions\n";
		return 0;
	}
	while (1){
		displayMenu();	
		cin >> choice;
		if (choice == '1'){
			functionPointer = &area;
			cout << "Area\n" << functionPointer (length, breadth) << "\n";
		}
		else if (choice == '2'){
			functionPointer = &perimeter;
			cout << "Perimeter\n" << (functionPointer (length, breadth)) << "\n";
		}    
		else if (choice == '3'){
			break;
		}
		else {
			cout << "Invalid input\n";
		}
	}
}
