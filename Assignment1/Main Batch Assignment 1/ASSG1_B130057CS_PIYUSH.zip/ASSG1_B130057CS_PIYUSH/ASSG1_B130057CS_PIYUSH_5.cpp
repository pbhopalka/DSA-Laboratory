#include <iostream>

int main() {
	int n;
	std::cout << "Enter the value of n\n";
	std::cin >> n;
	if (n < 0){
		std::cout << "Error\n";
		return 0;
	}
	int arrayCheck[100001] = {0};
	int matrix [n][1000], sum[1000];
	std::cout << "Enter the elements of matrix\n";
	int k = 0;
	if (n == 0){
		std::cout << "No\n";
		return 0;
	}
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++){ 
			if (!(std::cin >> matrix[i][j])){
				std::cout << "Invalid input\n";
				return 0;
			}
			arrayCheck[matrix[i][j]]++;
			sum[k] += matrix[i][j];
			//cout << sum[k] << "\n";
		}
		k++;
	}
	
	for (int i = 0; i < n; i++){
		for (int j = 0; j < n; j++){
			if (arrayCheck [matrix[i][j]] > 1 || arrayCheck [matrix[i][j]] < 0){
				std::cout << "No\n";
				return 0;
			}
			if (matrix [j][i] <= 0 || matrix [j][i] > (n*n)){
				std::cout << "No\n";
				return 0;
			}
			
			sum[k] += matrix[j][i];
			//cout << sum[k] << "\n";
		}
		k++;
	}
	for (int i = 0; i < n; i++){
		sum[k] += matrix[i][i];
		//cout << sum [k] << "\n";
	}
	k++;
	for (int i = 1; i < k ; i++){
		if (sum[i-1] != sum[i]){
			std::cout << "No\n";
			break;
		}
		if (i == k-1)	
			std::cout << "Yes\n";
	}
}
	
			
