#include <iostream>
#include <stdio.h>

using namespace std;

int stringLength (char String[]){ //similar to strlen in string.h
	int length = 0;
	for (int i = 0; ; i++){
		if (String [i] == '\0')
			break;
		else
			length++;
	}
	return length;
}

//union for id
union id {
	long long int aadharNumber;
	char voterId[8];
};

struct member {
	char name[100000];
	int age;
	id idNumber;
}mem; //global declaration

bool checkError(){ //if error is not present, it returns false else true
	if (mem.age <=0)
		return true;
	if (mem.age < 18) {
		if (mem.idNumber.aadharNumber == 0)
			return true;
	}
	else {
		int i, length = stringLength(mem.idNumber.voterId);
		if (length != 7) //VOTER-id is 7 in length
			return true;
		for (i = 0; i < length; i++){
			int ascii = (int) mem.idNumber.voterId[i];
			if (!((ascii >= 65 && ascii <=90) || (ascii >=48 && ascii <=57))) 
				break; //only block letters and numbers
		}
		if (i == length)
			return false;
		else
			return true;
	}
	return false;
}

void takeInput() { //function for taking input
	cout << "Enter name:\n";
	cin.getline(mem.name, 100000);
	cout << "Enter age:\n";
	cin >> mem.age;
	if (mem.age > 0 && mem.age < 18){
		cout << "Enter Aadhar Number\n";
		if (!(cin >> mem.idNumber.aadharNumber))
			return;
	}
	else if (mem.age >=18){
		cout << "Enter Voter-ID\n";
		cin >> mem.idNumber.voterId;
	}
	else {
		cout << "Invalid age\n";
	}	
}

void displayOutput() { //function for displaying the output
	cout << mem.name << "," << mem.age << ",";
	if (mem.age < 18)
		cout << mem.idNumber.aadharNumber << "\n";
	else
		cout << mem.idNumber.voterId << "\n";
}	
	
int main() {
	takeInput();
	if (checkError()){
		cout << "Error\n";
		return 0;
	}
	displayOutput();
}
	
