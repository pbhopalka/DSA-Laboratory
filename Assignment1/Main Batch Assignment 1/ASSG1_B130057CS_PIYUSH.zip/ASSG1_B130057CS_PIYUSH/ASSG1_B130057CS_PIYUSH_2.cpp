#include <iostream> 	

int stringLength (char String[]){ //similar to strlen in string.h
	int length = 0;
	for (int i = 0; ; i++){
		if (String [i] == '\0')
			break;
		else
			length++;
	}
	return length;
}

bool checkError (char String[]){ //validates that the input is correct
	int stringlength = stringLength(String), i;
	for (i = 0; i < stringlength; i++){
		int ascii = (int) String[i];
		if (!((ascii >= 65 && ascii <=90) || (ascii >=97 && ascii <=122)))
			break; //checks if the input has anything other than alphabets
	}
	if (i == stringlength)
		return true;
	return false;
}	

bool is_present (char subString[], char String[]) { //checks if a substring is present in a string
	for (int i = 0; i < stringLength (subString); i++) {
		if (subString [i] != String [i])
			return false;
	}
	return true;
}

int main() {
	char s1[1000000], s2[1000000];
	std::cout << "Enter String s1\n";
	std::cin.getline(s1, 1000000);
	std::cout << "Enter string s2\n";
	std::cin.getline(s2, 1000000);
	if (!((checkError(s1)) && (checkError(s2)))){
		std::cout << "Error\n";
		return 0;
	}
	int n1 = stringLength (s1);
	int j = 0, index[100000];
	for (int i = 0; i < n1; i++){
		if (s1[i] == s2[0]){
			if (is_present (s2, s1+i)){
				index[j] = i;
				j++;
			}
		}
	}
	if (j > 0){
		std::cout << "Yes" << "\n";
		for (int i = 0; i < j; i++)
			std::cout << index [i] << "\n";
	}
	else 
		std::cout << "No" << "\n";
}

	
