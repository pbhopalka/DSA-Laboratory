#include <iostream>
#include <cstdlib>
#include <fstream>

using namespace std;

struct record {
	char name[10000];
	char rollNumber[1000];
	char branch[100];
	int marks[5];
}studentRecord;

void inputRecord () {
	cout << "Enter Name, Roll number, Branch, Marks of 5 subjects\n";
	cin.ignore();
	cin.getline(studentRecord.name, 10000);
	cin >> studentRecord.rollNumber;
	cin >> studentRecord.branch;
	for (int i = 0; i < 5; i++){
		if (!(cin >> studentRecord.marks[i])){
			cout << "Invalid input\n";
			exit(0);
		}
	}
}

void printRecord() {
	cout << studentRecord.name << "\t" << studentRecord.rollNumber << "\t";
	cout << studentRecord.branch << "\t";
	for (int i = 0; i < 5; i++)
		cout << studentRecord.marks[i] << " ";
	cout << "\n";
}

void appendRecord(char filename[]) {
	fstream file;
	file.open(filename, ios::out|ios::app|ios::binary);
	inputRecord();
	file.write((char *)&studentRecord, sizeof (studentRecord));
	file.close();
}

void displayAllRecord(char filename[]) {
	fstream file;
	file.open(filename, ios::in|ios::binary);
	while (file.read((char *)&studentRecord, sizeof (studentRecord)))
		printRecord();
	file.close();
}

void countAndAverage(char filename[]) {
	fstream file;
	int sum = 0, count = 0;
	file.open(filename, ios::in|ios::binary);
	while(file.read((char *)&studentRecord, sizeof(studentRecord))){
		for (int i = 0; i < 5; i++)
			sum += studentRecord.marks[i];
		count++;
	}
	cout << "Total number of records = " << count << "\n";
	if (count == 0)
		cout << "No data to calculate average total\n";
	cout << "Average total marks = " << (float)sum / count << "\n";
}
	

void displayMenu() {
	cout << "Menu:\n";
	cout << "a) Append record\nb) Display all the records\n";
	cout << "c) Count the records and calculate the average total-marks\n";
	cout << "d) Exit\n";
	cout << "Enter your choice:";
}

int main(int argumentCount, char *filename[]){
	if (argumentCount == 1){
		cout << "No filename specified\n";
		return 0; 
	}
	char choice;
	while (1) {
		displayMenu();
		cin >> choice;
		if (choice == 'a')
			appendRecord(filename[1]);
		else if (choice == 'b')
			displayAllRecord(filename[1]);
		else if (choice == 'c')
			countAndAverage (filename[1]);
		else if (choice == 'd')
			break;
		else
			cout << "Invalid choice\n";
	}
}
