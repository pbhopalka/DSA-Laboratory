#include <iostream>

long long rev = 0;

bool errorInRange(long double N){ //if error is not present it returns true else false
	if (N != (int)N){ //check if N is not an integer
		return false;
	}
	if (N < 0 || N > 2147483648){ //check for range
		return false;
	}
	return true;
}

long long reverse (long long number, long long rev) {
	if (number > 0){
		int r = number % 10;
		//rev = rev*10 + r;
		rev = reverse (number / 10, rev*10 + r); //recursive function

	}
	return rev;
}

int main() {
	long double N;
	std::cout << "Enter the value of the number:" << "\n";
	if ((std::cin >> N && errorInRange(N))){ 
		//checks if input is stored in the variable and does necessary error checks
		long long c = reverse (N, rev);
		std::cout << c << "\n";
		return 0;
	}
	std::cout << "Error";
} 
