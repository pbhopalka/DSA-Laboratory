#include <iostream>

using namespace std;

int stringLength (char String[]){ //similar to strlen in string.h
	int length = 0;
	for (int i = 0; ; i++){
		if (String [i] == '\0')
			break;
		else
			length++;
	}
	return length;
}

bool checkError (char String[]){ //validates that the input is correct
	int stringlength = stringLength(String), i;
	for (i = 0; i < stringlength; i++){
		int ascii = (int) String[i];
		if (!((ascii >= 65 && ascii <=90) || (ascii >=97 && ascii <=122)))
			break; //checks if the input has anything other than alphabets
	}
	if (i == stringlength)
		return true;
	return false;
}

int is_palindrome (char a[], int l, int k)
{
	for (int i = 0, j = l-1; i < j; i++, j--)
	{
		if (i == k)
			j++;
		else if (j == k)
			i--;
		else if (a[i] != a[j])
			return 0;
	}
	return 1;
}

int main(){
	char a[10000];
	cout << "Enter your string: \n";
	cin.getline(a, 10000);
	if (! checkError(a)) {
		cout << "Error\n";
		return 0;
	}
	int count = 0, i, l = stringLength(a);
	for (i = 0; i < l; i++){
		if (is_palindrome (a, l, i)){
			cout << a[i] << "\n" << i << "\n";
			count ++;
		}
	}
	if (count == 0)
		cout << "Not possible" << "\n";
}
