#include <iostream>
#include <cstdlib>

using namespace std;

char a[11][11];
int m, n;

int stringLength (char String[]){ //similar to strlen in string.h
	int length = 0;
	for (int i = 0; ; i++){
		if (String [i] == '\0')
			break;
		else
			length++;
	}
	return length;
}

bool check_COP(char array[]) {
	//cout << array << endl;
	for (int i = 0; i < m; i++){
		int index;			
		for (index = 0; index < n; index++){
			//cout << 'p' << a[i][array[index] - '0'];
			if (a[i][array[index] - '0'] != '0')
				break;		
		}
		for (index =  index+1; index < n; index++){
			//cout << 'q' << a[i][array[index] - '0'];
			if (a[i][array[index] - '0'] != '1')
				break;	
		}
		for (index = index +1; index < n; index++){
			if (a[i][array[index] - '0'] != '0'){
				//cout << index << a[i][array[index] - '0'] << " ";
				return false;
			}
		}
	}
	return true;
}
			 

int permutation (char array[], int index) {
    int length = stringLength(array);
    //cout << array << endl;
    if (index == length-1) {
		if (check_COP (array)) {
			cout << "Yes\n";
			for (int i = 0; i < length; i++)
				cout << array[i] - 47 << " ";
			exit(0);
		}
        //cout << array<< "\n";
        return 0;
    }
    for (int i = index; i < length; i++) {
        char temp = array[i];
        array [i] = array [index];
        array [index] = temp;
		permutation(array, index+1);
		temp = array[i];
		array[i] = array[index];
		array[index] = temp;
		//permutation (array, index+1);
	}
    return 0;
}

int commonOnes () {
	//char a[11];
	char array [n];
	int i;
	for (i = 0; i < n; i++){
		array[i] = i + 48;
	}
	array[i] = '\0';
	//cout << array;
	permutation(array, 0);
	return 0;
		
}	 

int main () {
	ios_base::sync_with_stdio(true);
    cout << "Enter m and n:\n";
    if (! (cin >> m)){
		cout << "Invalid input\n";
		return 0;
	} 
    if (! (cin >> n)){
		cout << "Invalid input\n";
		return 0;
	}
	if (!((m > 0 || m < 11) && (n > 0 || n < 11))){
		cout << "Range of m not invalid\n";
		return 0;
	}
    cout << "Enter elements of matrix:\n\n";
    for (int i = 0; i < m; i++){
		for (int j = 0; j < n; j++) {
			cin >> a[i][j];
			if (!(a[i][j] == '1' || a[i][j] == '0')){
				cout << "Invalid Input\n";
				return 0;
			}
		}
	}
	//cout << a[0] << endl;
    commonOnes();
    cout << "No\n";
    return 0;
}

