#include <iostream>
#include <cstdio>

using namespace std;

struct node{
	int element;
	node *left;
	node *right;
} *item = NULL;

bool isLeaf(node *point){
	if (point->left == NULL && point->right == NULL){
		return true;
	}
	return false;
}

node* getParent(node *root, node *num){
	node *temp = NULL;
	temp = root;
	if (num->element == temp->element){
		return NULL;
	}
	if (temp->left != NULL){
		if (num->element == temp->left->element)
			return temp;	
	}
	if (temp->right != NULL) {
		if (num->element == temp->right->element)
			return temp;
	}
	if (num->element < temp->element){
		return getParent(temp->left, num);
	}
	else{
		return getParent(temp->right, num);
	}
}

node* getRightMost(node *root){
	while (root->right != NULL){
		root = root->right;
	}
	return root;
}

node* getLeftMost(node *root){
	while (root->left != NULL){
		root = root->left;
	}
	return root;
}

node* findMin(node *root){
	node *temp;
	temp = root;
	if (temp == NULL)
		return temp;
	if (temp->left != NULL)
		temp = getLeftMost(temp->left);
	return temp;
}

node* findMax(node *root){
	node *temp;
	temp = root;
	if (temp == NULL)
		return temp;
	if (temp->right != NULL)
		temp = getRightMost(temp->right);
	return temp;
}

int successor(node *root, node *num){
	if (root == NULL){
		cout << "NOT FOUND\n";
		return 0;
	}
	if (num->element == root->element){
		node *temp, *temp2;
		if (root->right != NULL){
			temp = findMin(root->right);
			cout << temp->element << "\n";
			return 1;
		}
		temp = getParent(item, num);
		temp2 = num;
		while (temp != NULL){
			if (temp->right == NULL){
				cout << temp->element << "\n";
				return 1;
			}
			if (temp2->element == temp->right->element){
				temp2 = temp;
				temp = getParent(item, temp);
			}
			else
				break;
		}
		if (temp == NULL){
			cout << "NIL\n";
		}
		else
			cout << temp->element << "\n";
		return 1;
	}
	else if(num->element < root->element){
		successor(root->left, num);
	}
	else
		successor(root->right, num);
	return 0;
}

int predeccesor(node *root, node *num, node *mainRoot){
	if (root == NULL){
		cout << "NOT FOUND\n";
		return 0;
	}
	if (num->element == root->element){
		node *temp, *temp2;
		if (root->left != NULL){
			temp = findMax(root->left);
			cout << temp->element << "\n";
			return 1;
		}
		temp = getParent(mainRoot, num);
		temp2 = num;
		while (temp != NULL){
			if (temp->left == NULL){
				cout << temp->element << "\n";
				return 1;
			}
			if (temp2->element == temp->left->element){
				temp2 = temp;
				temp = getParent(mainRoot, temp);
			}
			else 
				break;
		}
		if (temp == NULL){
			cout << "NIL\n";
		}
		else
			cout << temp->element << "\n";
		return 1;
	}
	else if(num->element < root->element){
		predeccesor(root->left, num, mainRoot);
	}
	else
		predeccesor(root->right, num, mainRoot);
	return 0;
}

int search(node *root, int num){
	if (root == NULL){
		cout << "NOT FOUND\n"; 
		return 0;
	}
	if (root->element == num){
		cout << "FOUND\n";
		return 1;
	}
	if (num < root->element)
		return search(root->left, num);
	else
		return search(root->right, num);
}

int insert(node *&root, node *num){
	node *temp = NULL;
	node *temp2;
	temp2 = root;
	while (temp2 != NULL){
		temp = temp2;
		if (num->element < temp2->element)
			temp2 = temp2->left;
		else
			temp2 = temp2->right;
	}
	//num->parent = temp;
	if (temp == NULL)
		root = num;
	else if (num->element < temp->element)
		temp->left = num;
	else
		temp->right = num;
}

int deleteNode(node *&root, node *num){
	node *temp, *temp2;
	if (root == NULL){
		cout << "NOT FOUND\n";
		return 0;
	}
	if (root->element == num->element){
		if (isLeaf(root)){
			cout << "n\n";
			root = NULL;
			return 0;
		}
		if (root->left == NULL){
			root = root->right;
			return 0;
		}
		if (root->right == NULL){
			root = root->left;
			return 0;
		}
		temp2 = getLeftMost(root->right);
		root->element = temp2->element;
		num->element = temp2->element;
		deleteNode(root->right, num);
		return 0;
	}
	if (num->element < root->element)
		deleteNode(root->left, num);
	else
		deleteNode(root->right, num);
	return 0;
}

int inOrder(node *root){
	if (root != NULL){
		inOrder(root->left);
		cout << root->element << " ";
		inOrder(root->right);
	}
	return 0;
}

int preOrder(node *root){
	if (root != NULL){
		cout << root->element << " ";
		preOrder(root->left);
		preOrder(root->right);
	}
	return 0;
}

int postOrder(node *root){
	if (root != NULL){
		postOrder(root->left);
		postOrder(root->right);
		cout << root->element << " ";
	}
	return 0;
}

int main(){
	int choice, data, toPrint;
	node *root = NULL;
	node *num = NULL;
	node *temp = NULL;
	char c;
	while(1){
		cin >> choice;
		switch(choice){
			case 0:
				return 0;
			case 1:
				c = getchar();
				if (c != ' '){
					cout << "There must be a space after the choice\n";
					break;
				}
				cin >> data;
				if (data < 0){
					cout << "Input is negative\n";
					break;
				}
				num = new node;
				num->element = data;
				num->left = NULL;
				num->right = NULL;
				insert(root, num);
				item = root;
				break;
			case 2:
				c = getchar();
				if (c != ' '){
					cout << "There must be a space after the choice\n";
					break;
				}
				cin >> data;
				if (data < 0){
					cout << "Input is negative\n";
					break;
				}
				search(root, data);
				break;
			case 3:
				temp = findMin(root);
				if (temp == NULL)
					cout << "NIL\n";
				else
					cout << temp->element << "\n";
				break;
			case 4:
				temp = findMax(root);
				if (temp == NULL)
					cout << "NIL\n";
				else
					cout << temp->element << "\n";
				break;
			case 5:
				c = getchar();
				if (c != ' '){
					cout << "There must be a space after the choice\n";
					break;
				}
				cin >> data;
				if (data < 0){
					cout << "Input is negative\n";
					break;
				}
				num = new node;
				num->element = data;
				num->left = NULL;
				num->right = NULL;
				predeccesor(root, num, root);
				break;
			case 6:
				c = getchar();
				if (c != ' '){
					cout << "There must be a space after the choice\n";
					break;
				}
				cin >> data;
				if (data < 0){
					cout << "Input is negative\n";
					break;
				}
				num = new node;
				num->element = data;
				num->left = NULL;
				num->right = NULL;
				successor(root, num);
				break;
			case 7:
				c = getchar();
				if (c != ' '){
					cout << "There must be a space after the choice\n";
					break;
				}
				cin >> data;
				if (data < 0){
					cout << "Input is negative\n";
					break;
				}
				num = new node;
				num->element = data;
				num->left = NULL;
				num->right = NULL;
				deleteNode(root, num);
				break;
			case 8:
				if (root == NULL)
					cout << "EMPTY";
				else
					inOrder(root);
				cout << "\n";
				break;
			case 9:
				if (root == NULL)
					cout << "EMPTY";
				else
					preOrder(root);
				cout << "\n";
				break;
			case 10:
				if (root == NULL)
					cout << "EMPTY";
				else
					postOrder(root);
				cout << "\n";
				break;
			default:
				cout << "Invalid choice\n";
				break;
		}
	}
	return 0;
}