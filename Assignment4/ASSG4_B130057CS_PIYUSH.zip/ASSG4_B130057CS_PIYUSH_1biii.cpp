#include <iostream>
#include <cstring>
#include <cmath>
#include <climits>

using namespace std;

struct node{
	int data;
	node *next;
} *root = NULL;


int tree[100000];
double A = (sqrt(5)-1)/2;
int treeSize = 0;
int size;

int anotherHashFunction(int key){
	return (size *(fmod((float)(key*A),1)));
}

int hashFunction(int key, int index){
	int firstHash = key % size;
	int secondHash = anotherHashFunction(key);
	return ((firstHash + (index*secondHash))% size);
}

int insert (int element){
	int position;
	for (int i = 0; i < size; i++){
		if (element < 0)
			position = hashFunction(element + size, i);
		else
			position = hashFunction(element, i);
		cout << position << " ";
		if (tree[position] == INT_MAX){
			tree[position] = element;
			cout << "\n";
			return 1;
		}
	}
	cout << "Hash table overflow\n";
	return 0;
}

int search (int element){
	int position;
	for (int i = 0; i < size; i++){
		if (element < 0)
			position = hashFunction(element + size, i);
		else
			position = hashFunction(element, i);
		cout << position << " ";
		if (tree[position] == INT_MAX){
			cout << "NOT FOUND\n";
			return 0;
		}
		if (tree[position] == element){
			cout << "FOUND\n";
			return 1;
		}
	}
	cout << "NOT FOUND\n";
	return 0;
}

int main(){
	for (int i = 0; i < 10000; i++)
		tree[i] = INT_MAX;
	int choice, element;
	cin >> size;
	while (1){
		cin >> choice;
		switch (choice){
			case 0:
				return 0;
			case 1:
				cin >> element;
				insert (element);
				break;
			case 2:
				cin >> element;
				search (element);
				break;
			default:
				cout << "Invalid option\n";
				break;
		}
	}
}