#include <iostream>
#include <cstring>

using namespace std;

struct node{
	char element;
	node *next;
	node *left;
	node *right;
}*root = NULL;

int push(node* &stack, node *num){
	if (stack == NULL){
		stack = num;
		return 0;
	}
	num->next = stack;
	stack = num;
	return 0;
}

node* pop(node* &stack){
	node *temp;
	if (stack == NULL)
		return NULL;
	temp = stack;
	stack = stack->next;
	return temp;
}

int inOrder(node *root){
	if (root != NULL){
		if (root->left != NULL)
			cout << "(";
		inOrder(root->left);
		cout << root->element;
		inOrder(root->right);
		if (root->right != NULL)
			cout << ")";
	}
	return 0;
}

int preOrder(node *root){
	if (root != NULL){
		cout << root->element;
		preOrder(root->left);
		preOrder(root->right);
	}
	return 0;
}

int postOrder(node *root){
	if (root != NULL){
		postOrder(root->left);
		postOrder(root->right);
		cout << root->element;
	}
	return 0;
}

bool searchOperator (char expression){ //return true if the item is an operator
	if (expression == '+' || expression == '-' || expression == '*' || expression == '^' || expression == '/')
		return true;
	return false;
}

int main(){
	char expression[100];
	cin >> expression;
	node *item = NULL, *left, *right;
	int expLength = strlen(expression);
	for (int i = 0; i < expLength; i++){
		item = new node;
		if (searchOperator(expression[i])){
			item->element = expression[i];
			right = pop (root);
			left = pop (root);
			item->left = left;
			item->right = right;
			push(root, item);
		}
		else{
			item->element = expression[i];
			push(root, item);
		}
	}
	inOrder(root);
	cout << "\n";
	preOrder(root);
	cout << "\n";
	postOrder(root);
	cout << "\n";
	return 0;
}