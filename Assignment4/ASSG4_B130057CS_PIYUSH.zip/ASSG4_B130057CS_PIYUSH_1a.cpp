#include <iostream>

using namespace std;

struct node{
	int data;
	node *next;
} *root = NULL;


node *tree[100000];
int treeSize = 0;
int size;

int insert (int element){
	if (element < 0)
		element = element + size;
	int index = element % size;
	node *temp;
	temp = new node;
	temp->data = element;
	temp->next = tree[index];
	tree[index] = temp;
	cout << index << "\n";
}

int search (int element){
	if (element < 0)
		element = element + size;
	int index = element % size;
	cout << index << " ";
	node *temp;
	temp = tree[index];
	while (temp != NULL){
		if (temp->data == element){
			cout << "FOUND\n";
			return 1;
		}
		else
			temp = temp->next;
	}
	cout << "NOT FOUND\n";
	return 0;
}

int main(){
	int choice, element;
	cin >> size;
	while (1){
		cin >> choice;
		switch (choice){
			case 0:
				return 0;
			case 1:
				cin >> element;
				insert (element);
				break;
			case 2:
				cin >> element;
				search (element);
				break;
			default:
				cout << "Invalid option\n";
				break;
		}
	}
}