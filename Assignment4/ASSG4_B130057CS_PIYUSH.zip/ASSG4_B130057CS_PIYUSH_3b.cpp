#include <iostream>
#include <cstring>

using namespace std;

struct node{
	char element;
	node *next;
	node *left;
	node *right;
}*root = NULL, *print = NULL;

int push(node* &stack, node *num){
	if (stack == NULL){
		stack = num;
		return 0;
	}
	num->next = stack;
	stack = num;
	return 0;
}

node* pop(node* &stack){
	node *temp;
	if (stack == NULL)
		return NULL;
	temp = stack;
	stack = stack->next;
	return temp;
}

int inOrder(node *root){
	do {
		
		while(root != NULL){
			if (root->left == NULL){
				cout << "(";
				cout << root->element;
				root = root->left;
			}
			else{
				if (root->right != NULL){
					push (print, root);
				}
				root = root->left;	
			}
		}
		root = pop(print);
		if (root != NULL){
			if (root->right != NULL)
				cout << root->element;
			root = root->right;
		}
		cout << ")";
	} while(root != NULL);
	return 0;
}

int postOrder(node *root){
	do {
		while(root != NULL){
			if (root->right != NULL){
				push (print, root->right);
			}
			push (print, root);
			root = root->left;
		}
		root = pop(print);
		if (root->right != NULL){
			pop(print);
			push(print, root);
			root = root->right;
		}
		else{
			cout << root->element;
			int a;
			cin >> a;
			root = NULL;
		}
	} while(print != NULL);
	return 0;
}

int preOrder(node *root){
	do {
		while(root != NULL){
			if (root->right != NULL){
				push (print, root);
			}
			cout << root->element;
			root = root->left;
		}
		root = pop(print);
		if (root != NULL)
			root = root->right;
	} while(root != NULL);
	return 0;
}

bool searchOperator (char expression){ //return true if the item is an operator
	if (expression == '+' || expression == '-' || expression == '*' || expression == '^' || expression == '/')
		return true;
	return false;
}

int main(){
	char expression[100];
	cin >> expression;
	node *item = NULL, *left, *right;
	int expLength = strlen(expression);
	for (int i = 0; i < expLength; i++){
		item = new node;
		if (searchOperator(expression[i])){
			item->element = expression[i];
			right = pop (root);
			left = pop (root);
			item->left = left;
			item->right = right;
			push(root, item);
		}
		else{
			item->element = expression[i];
			push(root, item);
		}
	}
	postOrder(root);
	
	cout << "\n";
	/*
	inOrder(root);
	cout << "\n";
	preOrder(root);
	cout << "\n";
	postOrder(root);
	cout << "\n";
	*/
	return 0;
}