#include <iostream>
#include <cmath>

using namespace std;

struct node{
	int data;
	node *left;
	node *right;
} *root = NULL;

struct list{
	int data;
	list *next;
} *lList[100];

int print_list(list *LinkedList[], int depth){
	cout << "Depth " << depth << endl;
	for (int i = 0; i <= depth; i++){
		if (LinkedList[i] != NULL){
			cout << LinkedList[i]->data;
			LinkedList[i] = LinkedList[i]->next;
		}
		while (LinkedList[i] != NULL){
			cout << " -> " << LinkedList[i]->data;
			LinkedList[i] = LinkedList[i]->next;
		}
		cout << "\n";
	}
}

int insert_list(list *LinkedList[], int index, list *&element){
	element->next = LinkedList[index];
	LinkedList[index] = element;
	return 0;
}

int make_list(node *tree, int k){
	if (tree == NULL)
		return 0;
	list *temp;
	temp = new list;
	temp->data = tree->data;
	temp->next = NULL;
	insert_list(lList, k, temp);
	k++;
	make_list(tree->right, k);
	make_list(tree->left, k);
	return 0;
}

int inOrder(node *tree){
	if (tree != NULL){
		inOrder(tree->left);
		cout << tree->data << " ";
		inOrder(tree->right);
	}
	return 0;
}

int insert_bst(node *&tree, node *num){
	if (tree == NULL){
		tree = num;
		return 0;
	}
	if (tree->data == num->data){
		cout << "Element already exists";
		return 0;
	}
	if (num->data < tree->data)
		insert_bst(tree->left, num);
	else
		insert_bst(tree->right, num);
	return 0;
}

int insertElementsInTree(node *&tree, int array[], int length){
	node *temp;
	for (int i = 0; i < length; i++){
		temp = new node;
		temp->data = array[i];
		temp->left = NULL;
		temp->right = NULL;
		insert_bst(tree, temp);
	}
	return 0;
}

int make_tree(node *&tree, int array[], int arraySize, int index){
	if (index < arraySize){
		if (array[index] == -1){
			tree = NULL;
			return 0;
		}
		else{
			tree = new node;
			tree->data = array[index];
			tree->left = NULL;
			tree->right = NULL;
		}
		make_tree(tree->left, array, arraySize, 2*index);
		make_tree(tree->right, array, arraySize, 2*index+1);
		return 0;
	}
}

int main(){
	int length;
	cin >> length;
	if (length == 0){
		cout << "ArraySize is 0\n";
		return 0;
	}
	/*int array[1000];
	int i = 1;
	do{
		cin >> array[i];
		i++;
	}while (cin.peek() !='\n');
	int depth = log2(i);
	make_tree(root, array, i, 1);*/
	int array[length], element, forDepth;
	for (int i = 0; i < length;){
		forDepth++;
		cin >> element;
		if (element != -1){
			array[i] = element;
			i++;
		}
	}
	int depth = log2(forDepth);
	insertElementsInTree(root, array, length);
	cout << "In-order traversal: ";
	inOrder(root);
	cout << "\n";
	make_list(root, 0);
	print_list(lList, depth);
	return 0;
}