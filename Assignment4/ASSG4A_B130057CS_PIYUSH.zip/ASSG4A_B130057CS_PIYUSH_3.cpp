#include <iostream>

using namespace std;

struct node{
	int data;
	node *left;
	node *right;
} *root = NULL;

int print_bst(node *tree){

	if (tree != NULL){
		//if (tree->left != NULL)
			cout << "(";
		cout << tree->data;
		print_bst(tree->left);
		print_bst(tree->right);
		//if (tree->right != NULL)
			cout << ")";
	}
	else{ 
		cout << "()";
	}
	return 0;
}

int insert_bst(node *&tree, node *element){
	if (tree == NULL){
		tree = element;
		return 0;
	}
	if (element->data == tree->data){
		cout << "Element already exists\n";
		return 0;
	}
	if (element->data < tree->data){
		insert_bst(tree->left, element);
	}
	else
		insert_bst(tree->right, element);
	return 0;
}

int main(){
	int array[1000], element;
	node *temp;
	int i = 0;
	//cin.getline(array, 1000);
	do{
		cin >> element;
		i++;
		temp = new node;
		temp->data = element;
		temp->left = NULL;
		temp->right = NULL;
		insert_bst(root, temp);
	}while (cin.peek() !='\n');
	print_bst(root);
	cout << "\n";
	return 0;
	/*while(1){

		if (!(cin >> element)) {//)
			print_bst(root);
			cout << "\n";
			return 0;
		}
		temp = new node;
		temp->data = element;
		temp->left = NULL;
		temp->right = NULL;
		insert_bst(root, temp);
		char c = cin.peek();
		if (c == '\n'){
			print_bst(root);
			cout << "\n";
			return 0;	
		}
		
	}
	*/
}