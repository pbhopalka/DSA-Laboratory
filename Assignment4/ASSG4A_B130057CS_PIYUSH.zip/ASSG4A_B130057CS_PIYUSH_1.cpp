#include <iostream>
#include <climits>

using namespace std;

struct node{
	int data;
	node *left;
	node *right;
} *root = NULL;

int minTree, maxTree;
int nodes = INT_MIN;

int maximumOf(int a, int b){
	if (a > b)
		return a;
	return b;
}

int getLargest(node *tree){
	if (tree != NULL){
		int check = 1;
		int forLeft, forRight;
		int lSide = getLargest(tree->left);
		if (lSide == 0)
			forLeft = tree->data;
		else
			forLeft = minTree;
		if ((lSide != 0 && tree->data <= maxTree) || (lSide == -1))
			check = 0;
		int rSide = getLargest(tree->right);
		if (rSide == 0)
			forRight = tree->data;
		else
			forRight = maxTree;
		if ((rSide != 0 && tree->data >= minTree) || (rSide == -1))
			check = 0;
		if (check == 1){
			minTree = forLeft;
			maxTree = forRight;
			int total = lSide + rSide + 1;
			nodes = maximumOf(total, nodes);
			return total;
		}
		else{
			return -1;
		}
	}
	return 0;
}

int inOrder(node *tree){
	if (tree != NULL){
		inOrder(tree->left);
		cout << tree->data << " ";
		inOrder(tree->right);
	}
	return 0;
}

int postOrder(node *tree){
	if (tree != NULL){
		postOrder(tree->left);
		postOrder(tree->right);
		cout << tree->data << " ";
	}
	return 0;
}

int make_tree(node *&tree, int array[], int arraySize, int index){
	if (index < arraySize){
		if (array[index] == -1){
			tree = NULL;
			return 0;
		}
		else{
			tree = new node;
			tree->data = array[index];
			tree->left = NULL;
			tree->right = NULL;
		}
		make_tree(tree->left, array, arraySize, 2*index);
		make_tree(tree->right, array, arraySize, 2*index+1);
		return 0;
	}
}

int main(){
	int arraySize;
	cin >> arraySize;
	if (arraySize == 0){
		cout << "ArraySize is 0\n";
		return 0;
	}
	int array[1000];
	int i = 1;
	do{
		cin >> array[i];
		i++;
	}while (cin.peek() !='\n');
	make_tree(root, array, i, 1);
	cout << "Inorder traversal: ";
	inOrder(root);
	cout << "\n";
	/*cout << "Post traversal: ";
	postOrder(root);
	cout << "\n";*/
	cout << "Maximum size of BST: ";
	getLargest(root);
	cout << nodes << "\n";
	return 0;
}