#include <iostream>
#include <algorithm>

using namespace std;

struct point{
	int value;
	int representative;
};

struct node{
	int x;
	int rank;
	node *next;
	node *representative;
} *head = NULL;

struct lList {
	node *data = NULL;
	lList *next;
} *list;

int array[1000][1000];

class Disjoint{
public:
int pushToList (lList *&list, node *point){
	lList *temp = new lList;
	temp->data = point;
	temp->next = NULL;
	if (list == NULL){
		list = temp; 
		return 0;
	}
	temp->next = list;
	list = temp;
}

node *findItem(lList *list, int x){
	while (list != NULL){
		if (x == list->data->x)
			return list->data;
		list = list->next;
	}
}

int makeSet (int x){
	node *point = new node;
	point->x = x;
	point->rank = 0;
	point->next = NULL;
	point->representative = point;
	pushToList(list, point);
	return 0;
}

node* findSet (node *point){
	if (point != point->representative)
		return findSet(point->representative);
	return point->representative;
}

node *tail(node *a){
	while(a->next != NULL){
		a = a->next;
	}
	return a;
}

int link(node *a, node *b){
	node *t;
	
	if (a->rank > b->rank){
		b->representative = a;
	}
	else{
		a->representative = b;
		if (a->rank == b->rank)
			b->rank++;
	}
}

int unionSets(node *x, node *y){
	node *a = findSet(x);
	node *b = findSet(y);
	if (a->x != b->x){
		link (a, b);
	}
	return 0;
}

};

struct Edge{
	int point1;
	int point2;
	int cost;
};

Edge edge[1000]; 

bool comp(Edge u, Edge v){
		return (u.cost < v.cost);
	}


class Graph{
	Disjoint set;
	int m = 0;
	int totalCount = 0;

public:

	
	Graph(int V) {
				
	}

	//Adding an edge point from vertex u
	int addEdge(int u, int v, int c){
	//	cout << "Value:" << graph[u].vertex << "\n";
		Edge temp;// = new Edge;
		temp.point1 = u;
		temp.point2 = v;
		temp.cost = c;
		edge[m] = temp;
	}	

	// Inserting the value v and c at graph[u] and then the reverse
	int insertInGraph (int u, int v, int c){
		addEdge(u, v, c);
		m++;
		return 0;
	}	

	int printMatrix(int N){
		for (int i = 0; i < N; i++){
			for (int j = 0; j < N; j++){
				cout << array[i][j] << " ";
			}
			cout << "\n";
		}
	}

	
	int kruskal(int N){
		for (int i = 0; i < N; i++){
			set.makeSet(i);
			//cout << list->data->x << " ";
		}
		sort(edge, edge+m, comp);
		for (int i = 0; i < m; i++){
			//cout << edge[i].point1 << " " << edge[i].point2 << endl;
			node *u = set.findItem(list, edge[i].point1);
			node *v = set.findItem(list, edge[i].point2);
			if (set.findSet(u)->x != set.findSet(v)->x){
				totalCount += edge[i].cost;
				array[edge[i].point1][edge[i].point2] = edge[i].cost;
				array[edge[i].point2][edge[i].point1] = edge[i].cost;
				set.unionSets(u, v);

			}
		}
		cout << totalCount << "\n";
		printMatrix(N);
	}

 
};

int main(){
	int N, E;
	cin >> N;
	cin >> E;	
	Graph g(N);
	for (int i = 0; i < E; i++){
		int u, v, c;
		cin >> u >> v >> c;
		g.insertInGraph(u, v, c);
	}
	//g.printGraph(N);
	g.kruskal(N);
	//g.printMatrix(N);
}
