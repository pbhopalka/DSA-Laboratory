#include <iostream>
#include <climits>
#include <cstdio>

using namespace std;

struct node {
	int value;
	int cost;
	int visit;
	int discover;
	int final;
	node *previous;

	node(){
		visit = 0;
		previous = NULL;
	}
};

struct lList {
	int vertex;
	lList *next;
};

class Queue {
	lList *head;
	lList *tail;
	char c;
	
	/*node *makePoint(int element){
		node *point = new node;
		point->value = element;
		point->next = NULL;
		return point;
	}*/

public:
	Queue(){
		head = NULL;
		tail = NULL;
	}

	int enqueue (node *point){
		lList *temp = new lList;
		temp->vertex = point->value;
		temp->next = NULL;
		if (head == NULL){
			head = temp;
		}
		if (tail == NULL){
			tail = temp;
			return 0;
		}
		tail->next = temp;
		tail = temp;
		return 0;
	}

	/*int enqueue (int element){
		cout << "CHECK START\n";
		node *point = makePoint (element);
		cout << "point made\n";
		if (this->head == NULL){
			cout << "Entered head\n";
			head = point;
			tail = point;
			return 0;
		}
		tail->next = point;
		tail = point;
		return 0;
	}*/

	int dequeue (){
		if (head == NULL){
			cout << "Queue is empty\n";
			return -1;
		}
		int temp = head->vertex;
		head = head->next;
		return temp;
	}

	bool isEmpty (){
		if (head == NULL)
			return true;
		return false;
	}

	int printQueue (){
		if (head == NULL){
			cout << "Queue is empty\n";
			return 0;
		}
		cout << "Printing the queue: \n";
		lList *item = head;
		while(item != NULL){
			cout << item->vertex << " ";
			item = item->next;
		}
		cout << "\n";
	}
};

class Graph{
	node *vertices[100];
	lList *list[100];
	int time = 0;
	int n;
public:
	Graph(int V) {
		n = V;
		for (int i = 0; i < V; i++){
			node *vertex = new node;
			vertex->value = i;
			vertex->visit = 0;
			vertices[i] = vertex;
			list[i] = NULL;
		}			
	}

	// Making the node so that it can be inserted in adjacency list
	node* makeNode (int v, int c){
		node *point = new node;
		point->value = v;
		point->cost = c;
		point->previous = NULL;
		return point;
	}

	//Adding an edge point from vertex u
	int addEdge(int u, node *point){
	//	cout << "Value:" << graph[u].vertex << "\n";
		lList *temp = new lList;
		temp->vertex = point->value;
		temp->next = NULL;
		if (list[u] == NULL){
			list[u] = temp;
			return 0;
		}
		temp->next = list[u];
		list[u] = temp;
	}	

	// Inserting the value v and c at graph[u] and then the reverse
	int insertInGraph (int u, int v, int c){
		node *point = makeNode(v, c);
		addEdge(u, point);
		point = makeNode(u, c);
		addEdge(v, point);
		return 0;
	}	

	//Printing the graph
	int printGraph(int N){
		for (int i = 0; i < N; i++){
			cout << vertices[i]->value;
			lList *temp = list[i];
			while (temp != NULL){
				cout << "->" << temp->vertex;
				temp = temp->next;
			}
			cout << "\n";
		}
		cout << "\n";
		return 0;
	}

	int dfsUtility(node *point){
		time++;
		point->discover = time;
		point->visit = -1;
		lList *i = list[point->value];
		while (i != NULL){
			node *temp = vertices[i->vertex];
			if (temp->visit == 0){
				temp->previous = point;
				dfsUtility(temp);
			}
			i = i->next;
		}
		point->visit = 1;
		time++;
		cout << point->value << " ";
		point->final = time;
	}

	int depthSearch (){
		for (int i = 0; i < n; i++){
			if (vertices[i]->visit == 0){
				dfsUtility(vertices[i]);
			}
		}
	}
 
};


int main(){
	int N, E;
	cin >> N;
	cin >> E;	
	Graph g(N);
	for (int i = 0; i < E; i++){
		int u, v, c;
		cin >> u >> v >> c;
		g.insertInGraph(u, v, c);
	}
	//g.printGraph(N);
	g.depthSearch();
	cout << "\n";
	//g.printGraph(N);*/
	return 0;
}


