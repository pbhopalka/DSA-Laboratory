#include <iostream>
#include <climits>
#include <cstdio>

using namespace std;

struct node {
	int value;
	int distance;
	node *previous;
};

struct lList {
	node* vertex;
	int cost;
	lList *next;
};

int totalCost = 0;
node* vertices[100];

class PriorityQueue{

	int pValue[10000000];
	int array[10000000];
	int heapSize = -1;

public:

	PriorityQueue(){

	}

	int parent (int index){
	return index/2;
	}

	int leftChild (int index){
		return index*2;
	}

	int rightChild (int index){
		return leftChild(index)+1;
	}

	int swap (int someArray[], int i, int j){
		int temp;
		temp  = someArray[i];
		someArray[i] = someArray[j];
		someArray[j] = temp;
		return 0;
	}

	int maxHeapify(int index) {
		int largest;
		int left = leftChild (index);
		int right = rightChild (index);
		if ((left <= heapSize) && (pValue[left] < pValue[index]))
			largest = left;
		else
			largest = index;
		if ((right <= heapSize) && (pValue[right] < pValue[index]))
			largest = right;
		if (largest != index){
			swap (pValue, index, largest);
			swap (array, index, largest);
			maxHeapify(largest);
		}
		return 0;
	}

	node* remove() {
		if (heapSize < 0){
			cout << "EMPTY\n";
			return NULL;
		}
		int minInArray = array[0];
		int minInPvalue = pValue[0];
		array[0] = array[heapSize];
		pValue[0] = pValue[heapSize];
		heapSize--;
		maxHeapify(0);
		node *value = vertices[minInArray];
		//cout << minInArray << " (" << minInPvalue <<")\n";
		return value;
	}

	node* peek() {
		if (heapSize < 0){
			cout << "EMPTY\n";
			return NULL;
		}
		node *value = new node;
		value->value = array[0];
		value->distance = pValue[0];
		cout << array[0] << " (" << pValue[0]<<")\n";
		return value;
	}

	int increaseKey(int index, int element){
		pValue[index] = element;
		while (index > 0 && pValue[parent(index)] > pValue[index]){
			swap (pValue, index, parent(index));
			swap (array, index, parent(index));
			index = parent(index);
		}
		return index;
	}

	int insert(int element, int priority) {
		heapSize++;
		pValue[heapSize] = INT_MIN;
		array[heapSize] = INT_MIN;
		int index = increaseKey(heapSize, priority);
		array[index] = element;
		return 0;
	}

	int search (int element){
		for (int i = 0; i <= heapSize; i++){
			if (array[i] == element)
				return i;
		}
		return -1;
	}

	bool searchList (int element){
		for (int i = 0; i <= heapSize; i++){
			if (array[i] == element)
				return true;
		}
		return false;
	}

	bool isEmpty(){
		if (heapSize < 0)
			return true;
		else
			return false;
	}

};

class Graph{
	
	lList *list[100];
public:

	int array[1000][1000];
	Graph(int V) {
		for (int i = 0; i < V; i++){
			node *temp = new node;
			temp->value = i;
			temp->distance = INT_MAX; 
			temp-> previous = NULL;
			vertices[i] = temp;
			list[i] = NULL;
		}			
	}

	// Making the node so that it can be inserted in adjacency list
	node* makeNode (int v, int c){
		node *point = new node;
		point->value = v;
		point->distance = INT_MAX;
		point->previous = NULL;
		return point;
	}

	//Adding an edge point from vertex u
	int addEdge(int u, int v, int c){
	//	cout << "Value:" << graph[u].vertex << "\n";
		lList *temp = new lList;
		temp->vertex = vertices[v];
		temp->cost = c;
		temp->next = NULL;
		if (list[u] == NULL){
			list[u] = temp;
			return 0;
		}
		temp->next = list[u];
		list[u] = temp;
	}	

	// Inserting the value v and c at graph[u] and then the reverse
	int insertInGraph (int u, int v, int c){
		addEdge(u, v, c);
		addEdge(v, u, c);
		return 0;
	}	

	//Printing the graph
	int printGraph(int N){
		for (int i = 0; i < N; i++){
			cout << vertices[i]->value;
			lList *temp = list[i];
			while (temp != NULL){
				cout << "->" << temp->vertex->value << '(' << temp->cost << ')';
				temp = temp->next;
			}
			cout << "\n";
		}
		cout << "\n";
		return 0;
	}

	/*int convertToMatrix(int N){
		for (int i = 0; i < N; i++){
			for (int j = 0; j < N; j++){
				array[i][j] = 0;
			}
		}
		for (int i = 0; i < N; i++){
			lList *l = list[i];
			while (l != NULL){
				if (l->vertex->previous != NULL){
					cout << l->vertex->previous->value << " " << l->vertex->value << " " << i << endl;
					array[i][l->vertex->value] = l->vertex->distance;
					array[l->vertex->value][i] = l->vertex->distance;
				}
				l = l->next;
			}			
		}
	}*/

	int printMatrix(int N){
		for (int i = 0; i < N; i++){

			cout << vertices[i]->distance << " ";
		}
	}

	int djikstra (int source, int N){
		for (int i = 0; i < N; i++){
			vertices[i]->distance = INT_MAX;
			vertices[i]->previous = NULL;
		}
		vertices[source]->distance = 0;
		PriorityQueue *Q = new PriorityQueue;
		for (int i = 0; i < N; i++){
			//cout << vertices[i]->value << endl;
			Q->insert(vertices[i]->value, vertices[i]->distance);
			//Q->peek();
		}
		while (! Q->isEmpty()){
			node *p = Q->remove();
			//cout << p->distance << " ";
			lList *i;
			i = list[p->value];
			while(i != NULL){
				if (i->vertex->distance > (p->distance + i->cost)){
					i->vertex->previous = p;
					i->vertex->distance = (p->distance + i->cost);
					int index = Q->search(i->vertex->value);
					//cout << index << " " << i->vertex->value << endl;
					if (index >= 0){
						Q->increaseKey(index, i->vertex->distance);
						//Q->peek();
					}
				}
				/*if (Q->searchList(i->vertex->value) && (i->vertex->cost < i->vertex->distance)){
					i->vertex->previous = p;
					//cout << i->vertex->value << " " << p->value << endl;
					i->vertex->distance = i->vertex->cost;
					int index = Q->search(i->vertex->value);
					Q->increaseKey(index, i->vertex->distance);
					//totalCost = totalCost + i->vertex->cost;
					//cout << i->vertex->cost << " " << i->vertex->value << endl;
				}*/
				i = i->next;
			}
			
		}
		cout << "\n";
		//convertToMatrix(N);
		cout << "\n";
		//printMatrix(N);
	}
 
};

int main(){
	int N, E;
	cin >> N;
	cin >> E;	
	Graph g(N);
	for (int i = 0; i < E; i++){
		int u, v, c;
		cin >> u >> v >> c;
		g.insertInGraph(u, v, c);
	}
	//g.printGraph(N);
	int element;
	cout << "Value of element: ";
	cin >> element;
	g.djikstra(element, N);
	g.printMatrix(N);
	cout << "\n";
	//g.printGraph(N);
	//cout << "\n" <
}