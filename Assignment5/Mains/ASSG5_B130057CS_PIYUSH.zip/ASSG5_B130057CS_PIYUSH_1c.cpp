#include <iostream>

using namespace std;

struct node{
	int x;
	int rank;
	node *next;
	node *representative;
} *head = NULL;

struct lList {
	node *data = NULL;
	lList *next;
} *list;

int pushToList (node *point){
	lList *temp = new lList;
	temp->data = point;
	temp->next = NULL;
	if (list == NULL){
		list = temp; 
		return 0;
	}
	temp->next = list;
	list = temp;
}

node *findItem(lList *list, int x){
	while (list != NULL){
		if (x == list->data->x)
			return list->data;
		list = list->next;
	}
}

int makeSet (int x){
	node *point = new node;
	point->x = x;
	point->rank = 0;
	point->next = NULL;
	point->representative = point;
	pushToList(point);
	return 0;
}

node* findSet (node *point){
	if (point != point->representative)
		return findSet(point->representative);
	return point->representative;
}

node *tail(node *a){
	while(a->next != NULL){
		a = a->next;
	}
	return a;
}

int weight(node *a){
	int count = 0;
	while(a != NULL){
		count ++;
		a = a->next;
	}
	return count;
}

int link(node *a, node *b){
	node *t;
	
	if (a->rank > b->rank){
		b->representative = a;
	}
	else{
		a->representative = b;
		if (a->rank == b->rank)
			b->rank++;
	}
}

int unionSets(node *x, node *y){
	node *a = findSet(x);
	node *b = findSet(y);
	if (a->x != b->x){
		node *t = tail(a);
		t->next = b;
		b->representative = a;
	}
	return 0;
}

int main(){
	int choice, data;
	while (1){
		cin >> choice;
		switch (choice){
			case 0:
				return 0;
				break;
			case 1:
				cin >> data;	
				makeSet(data);
				break;
			case 2: { 
				cin >> data;
				node *point = findItem(list, data);
				node *fromPoint = findSet(point);
				cout << fromPoint->representative->x << endl;
				break;
			}
			case 3: {	
				int data1, data2;
				cin >> data1 >> data2;
				node *point1 = findItem(list, data1);
				node *point2 = findItem(list, data2);
				unionSets(point1, point2);
				break;
			}
			default:
				cout << "Invalid choice\n";
		}
	}
	return 0;
}
