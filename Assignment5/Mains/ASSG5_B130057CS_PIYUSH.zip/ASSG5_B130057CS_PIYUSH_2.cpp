#include <iostream>
#include <climits>
#include <cstdio>

using namespace std;

struct node {
	int value;
	int cost;
	int visit; //0 represents not visited, 1 represents visited;
		       //-1 represents not completely visited;
	int distance;
	node *previous;

	node(){
		visit = 0;
		distance = INT_MAX;
		previous = NULL;
	}
};

struct lList {
	int vertex;
	lList *next;
};

class Queue {
	lList *head;
	lList *tail;
	char c;
	
	/*node *makePoint(int element){
		node *point = new node;
		point->value = element;
		point->next = NULL;
		return point;
	}*/

public:
	Queue(){
		head = NULL;
		tail = NULL;
	}

	int enqueue (node *point){
		lList *temp = new lList;
		temp->vertex = point->value;
		temp->next = NULL;
		if (head == NULL){
			head = temp;
		}
		if (tail == NULL){
			tail = temp;
			return 0;
		}
		tail->next = temp;
		tail = temp;
		return 0;
	}

	/*int enqueue (int element){
		cout << "CHECK START\n";
		node *point = makePoint (element);
		cout << "point made\n";
		if (this->head == NULL){
			cout << "Entered head\n";
			head = point;
			tail = point;
			return 0;
		}
		tail->next = point;
		tail = point;
		return 0;
	}*/

	int dequeue (){
		if (head == NULL){
			cout << "Queue is empty\n";
			return -1;
		}
		int temp = head->vertex;
		head = head->next;
		return temp;
	}

	bool isEmpty (){
		if (head == NULL)
			return true;
		return false;
	}

	int printQueue (){
		if (head == NULL){
			cout << "Queue is empty\n";
			return 0;
		}
		cout << "Printing the queue: \n";
		lList *item = head;
		while(item != NULL){
			cout << item->vertex << " ";
			item = item->next;
		}
		cout << "\n";
	}
};

class Graph{
	node *vertices[100];
	lList *list[100];
public:
	Graph(int V) {
		for (int i = 0; i < V; i++){
			node *vertex = new node;
			vertex->value = i;
			vertex->visit = 0;
			vertex->distance = INT_MAX;
			vertices[i] = vertex;
			list[i] = NULL;
		}			
	}

	// Making the node so that it can be inserted in adjacency list
	node* makeNode (int v, int c){
		node *point = new node;
		point->value = v;
		point->cost = c;
		point->previous = NULL;
		return point;
	}

	//Adding an edge point from vertex u
	int addEdge(int u, node *point){
	//	cout << "Value:" << graph[u].vertex << "\n";
		lList *temp = new lList;
		temp->vertex = point->value;
		temp->next = NULL;
		if (list[u] == NULL){
			list[u] = temp;
			return 0;
		}
		temp->next = list[u];
		list[u] = temp;
	}	

	// Inserting the value v and c at graph[u] and then the reverse
	int insertInGraph (int u, int v, int c){
		node *point = makeNode(v, c);
		addEdge(u, point);
		point = makeNode(u, c);
		addEdge(v, point);
		return 0;
	}	

	//Printing the graph
	int printGraph(int N){
		for (int i = 0; i < N; i++){
			cout << vertices[i]->value;
			lList *temp = list[i];
			while (temp != NULL){
				cout << "->" << temp->vertex;
				temp = temp->next;
			}
			cout << "\n";
		}
		cout << "\n";
		return 0;
	}

	int breadthSearch (int element){
		node *u = vertices[element];
		u->visit = -1;
		u->distance = 0;
		u->previous = NULL;	
		Queue *queue = new Queue;
		cout << "breadth search:\n";
		queue->enqueue(u);
		cout << u->value << " ";
		//queue->printQueue();
		while (! queue->isEmpty()){
			int point = queue->dequeue();
			//queue->printQueue();
			lList *i;
			if (point == -1)
				i = NULL;
			else
				i = list[point];
			while (i != NULL){
				node *temp = vertices[i->vertex];
				if (temp->visit == 0){
					temp->visit = -1;
					temp->distance = vertices[point]->distance + 1;
					temp->previous = vertices[point];
					queue->enqueue(temp);
					cout << temp->value << " "; 
					//cout << "AfterQueue: ";
					//queue->printQueue();
				}
				i = i->next;
			}
			vertices[point]->visit = 1;
		}
	}
 
};


int main(){
	int N, E;
	cin >> N;
	cin >> E;	
	if (N < 0 || E < 0){
		cout << "Invalid inputs\n";
		return 0;
	}
	Graph g(N);
	for (int i = 0; i < E; i++){
		int u, v, c;
		cin >> u >> v >> c;
		g.insertInGraph(u, v, c);
	}
	//g.printGraph(N);
	int element;
	cout << "Value of element: ";
	cin >> element;
	g.breadthSearch(element);
	cout << "\n";
	//g.printGraph(N);*/
	return 0;
}


