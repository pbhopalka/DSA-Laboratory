#include <iostream>

using namespace std;

struct node{
	int x;
	int weight;
	node *next;
	node *representative;
} *head = NULL;

struct lList {
	node *data = NULL;
	lList *next;
} *list;

int pushToList (node *point){
	lList *temp = new lList;
	temp->data = point;
	temp->next = NULL;
	if (list == NULL){
		list = temp; 
		return 0;
	}
	temp->next = list;
	list = temp;
}

node *findItem(lList *list, int x){
	while (list != NULL){
		if (x == list->data->x)
			return list->data;
		list = list->next;
	}
}

int makeSet (int x){
	node *point = new node;
	point->x = x;
	point->weight = 1;
	point->next = NULL;
	point->representative = point;
	pushToList(point);
	return 0;
}

node* findSet (int x){
	node *point = findItem(list, x);
	return (point->representative);
}

node *tail(node *a){
	while(a->next != NULL){
		a = a->next;
	}
	return a;
}

int unionSets(int x, int y){
	node *a = findSet(x);
	node *b = findSet(y);
	if (a->x != b->x){
		node *t = tail(a);
		t->next = b;
		while(b != NULL){
			b->representative = a;
			b = b->next;
		}
	}
	return 0;
}

int main(){
	int choice, data;
	while (1){
		cin >> choice;
		switch (choice){
			case 0:
				return 0;
				break;
			case 1:
				cin >> data;	
				makeSet(data);
				break;
			case 2: {
				cin >> data;
				node *temp = findSet(data);
				cout << temp->x << endl;
				break;
			}
			case 3:{ 	
				int data1, data2;
				cin >> data1 >> data2;
				unionSets(data1, data2);
				break;
			}
			default:
				cout << "Invalid choice\n";
		}
	}
	return 0;
}
