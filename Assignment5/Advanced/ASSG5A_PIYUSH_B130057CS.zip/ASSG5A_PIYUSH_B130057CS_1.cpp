#include <iostream>
#include <climits>
#include <cstdio>

using namespace std;

struct node {
	int value;
	int visit;
	int discover;
	int final;
	int distance;
	node *previous;

	node(){
		visit = 0;
		previous = NULL;
	}
};

struct lList {
	node* vertex;
	int cost;
	lList *next;
};

struct sorted{
	node* vertex;
	sorted *next;
} *sort = NULL;

class Queue {
	lList *head;
	lList *tail;
	char c;
	
	/*node *makePoint(int element){
		node *point = new node;
		point->value = element;
		point->next = NULL;
		return point;
	}*/

public:
	Queue(){
		head = NULL;
		tail = NULL;
	}

	int enqueue (node *point){
		lList *temp = new lList;
		temp->vertex = point;
		temp->next = NULL;
		if (head == NULL){
			head = temp;
		}
		if (tail == NULL){
			tail = temp;
			return 0;
		}
		tail->next = temp;
		tail = temp;
		return 0;
	}

	/*int enqueue (int element){
		cout << "CHECK START\n";
		node *point = makePoint (element);
		cout << "point made\n";
		if (this->head == NULL){
			cout << "Entered head\n";
			head = point;
			tail = point;
			return 0;
		}
		tail->next = point;
		tail = point;
		return 0;
	}*/

	node* dequeue (){
		if (head == NULL){
			cout << "Queue is empty\n";
			return NULL;
		}
		node* temp = head->vertex;
		head = head->next;
		return temp;
	}

	bool isEmpty (){
		if (head == NULL)
			return true;
		return false;
	}

	int printQueue (){
		if (head == NULL){
			cout << "Queue is empty\n";
			return 0;
		}
		cout << "Printing the queue: \n";
		lList *item = head;
		while(item != NULL){
			cout << item->vertex->value << " ";
			item = item->next;
		}
		cout << "\n";
	}
};

int totalCost = 0;

class Graph{

public:
	node *vertices[100];
	lList *list[100];
	int time = 0;
	int n;

	int insertinSorted(node *point){
		sorted *temp = new sorted;
		temp->vertex = point;
		temp->next = NULL;
		if (sort == NULL){
			sort = temp;
			return 0;
		}
		temp->next = sort;
		sort = temp;

	}

	Graph(int V) {
		n = V;
		for (int i = 1; i <= V; i++){
			node *vertex = new node;
			vertex->value = i;
			vertex->visit = 0;
			vertices[i] = vertex;
			list[i] = NULL;
		}			
	}

	// Making the node so that it can be inserted in adjacency list
	node* makeNode (int v){
		node *point = new node;
		point->value = v;
		point->previous = NULL;
		return point;
	}

	//Adding an edge point from vertex u
	int addEdge(int u, int c, node *point){
	//	cout << "Value:" << graph[u].vertex << "\n";
		lList *temp = new lList;
		temp->vertex = point;
		temp->cost = c;
		temp->next = NULL;
		if (list[u] == NULL){
			list[u] = temp;
			return 0;
		}
		temp->next = list[u];
		list[u] = temp;
	}	

	// Inserting the value v and c at graph[u] and then the reverse
	int insertInGraph (int u, int v, int c){
		vertices[v]->previous = NULL;
		addEdge(u, c, vertices[v]);
		//point = makeNode(u, c);
		//addEdge(v, point);
		return 0;
	}	

	//Printing the graph
	int printGraph(int N){
		for (int i = 1; i <= N; i++){
			cout << vertices[i]->value;
			lList *temp = list[i];
			while (temp != NULL){
				cout << "->" << temp->vertex->value << "(" << temp->cost << ")" << " ";
				temp = temp->next;
			}
			cout << "\n";
		}
		cout << "\n";
		return 0;
	}

	int dfsUtility(node *point){
		time++;
		point->discover = time;
		point->visit = -1;
		lList *i = list[point->value];
		while (i != NULL){
			node *temp = vertices[i->vertex->value];
			if (temp->visit == 0){
				temp->previous = point;
				dfsUtility(temp);
			}
			i = i->next;
		}
		point->visit = 1;
		time++;
		//cout << point->value << " ";
		point->final = time;
		//insertinSorted(point);
		sorted *temp = new sorted;
		temp->vertex = point;
		temp->next = sort;
		sort = temp;
	}

	int depthSearch (int source){
		node *temp = vertices[source];
		dfsUtility(temp);
	}

	
	int printAnother(){
		char c;
		sorted *temp = sort;
		while (temp!= NULL){
			cout << temp->vertex->value << " ";
			//cin >> c;
			temp = temp->next;
		}
	}

	int relax(node *point1, node *point2, int cost){
		//cout << point2->distance << " p";
		if (point2->distance > (point1->distance + cost)){
			point2->distance = (point1->distance + cost);
			point2->previous = point1;
		}
	}

	int shortestPath(int source, int destination){
		//topological();
		depthSearch(source);
		//printAnother();
		cout << "\n";
		for (int i = 1; i <= n; i++){
			vertices[i]->distance = INT_MAX;
			vertices[i]->previous = NULL;
		}
		vertices[source]->distance = 0;
		for(sorted *i = sort; i != NULL; i = i->next){
			//cout << i->vertex->value << " ";
			for (lList *j = list[i->vertex->value]; j != NULL; j= j->next){
				//cout << j->vertex->distance << endl;
				relax(i->vertex, j->vertex, j->cost);
				//cout << j->vertex->value << " ";
			}
		}
	}

	

	int print(node* s, node* d){
		//cout << s->value << " " << d->value << endl;
		if (s == d){
			cout << (char)(d->value+ 'A' - 1) << "->";
		}
		else if (d == NULL){
			cout << "No path\n";
			return 0;
		}
		else{
			print(s, d->previous);
			cout << (char)(d->value+ 'A' - 1) << "->";
		}
		//cout << "\n";
	}
 
};


int main(){
	int N, E;
	cin >> N;
	cin >> E;	
	Graph g(N);
	char s, d;
	int source, destination;
	cin >> s >> d;
	source = s - 64;
	destination = d - 64;
	for (int i = 0; i < E; i++){
		char a, b;
		int c;
		cin >> a >> b >> c;
		int u = a - 64;
		int v = b - 64;
		//cout << u << " " << v << " " << c << endl;
		g.insertInGraph(u, v, c);
	}
	//g.printGraph(N);
	g.printGraph(N);
	//g.topological();
	cout <<  "\n";
	//g.printAnother();
	g.shortestPath(source, destination);
	node *temp = g.vertices[source];
	node *temp2 = g.vertices[destination];
	//cout << temp2->value << endl;
	if (temp2->distance == INT_MAX)
		cout << "No path\n";
	else
		g.print(temp, temp2);
	cout << "\n";
	//cout << totalCost << "\n";
	return 0;
}


